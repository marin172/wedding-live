const PASSWORD = "yumimari06251225";

function checkPassword() {
  const input = document.getElementById("password-input").value;
  const error = document.getElementById("error-msg");

  if (input === PASSWORD) {
    document.getElementById("lock-screen").style.display = "none";
    document.getElementById("main-content").style.display = "block";
  } else {
    error.textContent = "Incorrect password. Try again.";
  }
}